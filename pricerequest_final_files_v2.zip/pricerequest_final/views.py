import base64

from django.core.exceptions import ObjectDoesNotExist
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters, status, viewsets
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.pagination import PageNumberPagination
from django.utils import timezone

from pricerequest.api_permissions import IsApplicationUser
from pricerequest.filters import TicketByStatusFilter
from pricerequest.models import (
    Ticket, TicketLine, TicketStatus, CCIPriceList, ContactEmails,
    TicketStatusChoices, AnnouncementMailLink,
)
from pricerequest.roles import ADMIN_ROLE
from pricerequest.serializers import (
    TicketLineReadSerializer, TicketLineWriteSerializer,
    TicketStatusSerializer, TicketReadSerializer, TicketWriteSerializer,
    CCIPriceListSerializer, ContactEmailsSerializer,
    AnnouncementMailLinkSerializer,
)
from pricerequest.workflow import (
    get_user_roles, is_valid_ticket_transition,
    is_role_allowed_for_ticket_status, get_intermediate_statuses,
)
from pricerequest.notification import (
    handle_announcement_emails, handle_pm_or_salesops_emails,
)


class StandardPagination(PageNumberPagination):
    page_size = 8
    page_size_query_param = "page_size"
    max_page_size = 25


def get_ticket_status(ticket_id):
    """Return the most recently created status history row for a ticket."""
    return TicketStatus.objects.filter(ticket_number_id=ticket_id).order_by("-id").first()


class TicketView(viewsets.ModelViewSet):
    permission_classes = [IsApplicationUser]
    queryset = Ticket.objects.all()
    pagination_class = StandardPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter, TicketByStatusFilter]
    filterset_fields = {
        "id": ["exact"],
        "ticket_number": ["exact"],
        "meta_created_date": ["exact", "gt", "lt", "gte", "lte"],
        "meta_edited_date": ["exact", "gt", "lt", "gte", "lte"],
        "start_date": ["exact", "gt", "lt", "gte", "lte"],
        "end_date": ["exact", "gt", "lt", "gte", "lte"],
    }
    search_fields = ["ticket_number", "subject"]
    ordering_fields = ["ticket_number", "meta_created_date", "meta_edited_date", "start_date", "end_date"]
    ordering = ["ticket_number"]

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return TicketWriteSerializer
        return TicketReadSerializer

    def perform_create(self, serializer):
        email_list = self.request.data.get("email_cc")
        ticket = serializer.save(meta_created_by=self.request.user, email_cc=email_list)
        TicketStatus.objects.create(
            ticket_number=ticket,
            status=TicketStatusChoices.DRAFT,
            meta_created_by=self.request.user,
        )

    def perform_update(self, serializer):
        ticket_id = self.get_object().pk
        current_status = get_ticket_status(ticket_id)
        editable_statuses = {
            TicketStatusChoices.DRAFT,
            TicketStatusChoices.PM_REJECTED,
            TicketStatusChoices.SALESOPS_REJECTED,
        }
        if not current_status or current_status.status not in editable_statuses:
            raise PermissionDenied("You can't edit this Price Setup Request!")
        serializer.save(
            meta_edited_by=self.request.user,
            meta_edited_date=timezone.now(),
            email_cc=self.request.data.get("email_cc"),
        )

    def perform_destroy(self, instance):
        current_status = get_ticket_status(instance.pk)
        deletable_statuses = {
            TicketStatusChoices.DRAFT,
            TicketStatusChoices.PM_REJECTED,
            TicketStatusChoices.SALESOPS_REJECTED,
        }
        is_admin = self.request.user.groups.filter(name=ADMIN_ROLE).exists()
        if (current_status and current_status.status in deletable_statuses) or is_admin:
            return super().perform_destroy(instance)
        raise PermissionDenied(f"Only {ADMIN_ROLE} can delete this request.")


class TicketLineView(viewsets.ModelViewSet):
    permission_classes = [IsApplicationUser]
    queryset = TicketLine.objects.all()
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = {"ticket_number": ["exact"]}

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return TicketLineWriteSerializer
        return TicketLineReadSerializer

    def perform_create(self, serializer):
        serializer.save(meta_created_by=self.request.user)

    def perform_update(self, serializer):
        serializer.save(meta_edited_by=self.request.user, meta_edited_date=timezone.now())


class TicketStatusView(viewsets.ModelViewSet):
    permission_classes = [IsApplicationUser]
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    queryset = TicketStatus.objects.all()
    serializer_class = TicketStatusSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = {
        "ticket_number": ["exact"],
        "meta_created_date": ["exact", "gt", "lt", "gte", "lte"],
    }
    search_fields = ["status"]
    ordering_fields = ["meta_created_date"]
    ordering = ["meta_created_date"]

    def create(self, request, *args, **kwargs):
        # Multipart requests carry status and ticket_number in request.POST; JSON requests use request.data.
        response = super().create(request, *args, **kwargs)
        return response

    def perform_create(self, serializer):
        files = self.request.FILES.getlist("Upload_files")
        data = self.request.data
        comments = data.get("comment")
        target_status = data.get("status")
        ticket_number = data.get("ticket_number")
        if comments in ("", None, "null"):
            comments = None
        if not target_status or not ticket_number:
            raise ValidationError({"detail": "Both ticket_number and status are required."})

        try:
            ticket = Ticket.objects.get(ticket_number=ticket_number)
        except Ticket.DoesNotExist:
            raise ValidationError({"ticket_number": "Ticket not found."})

        current_status_record = get_ticket_status(ticket.pk)
        if not current_status_record:
            raise ValidationError({"status": "No initial status exists for this ticket."})
        current_status = current_status_record.status

        if not is_valid_ticket_transition(current_status, target_status):
            raise ValidationError({"status": f"Invalid status transition from {current_status} to {target_status}."})

        user_roles = get_user_roles(self.request.user)
        if not is_role_allowed_for_ticket_status(user_roles, target_status):
            raise PermissionDenied(f"Your role is not allowed to set status {target_status}.")

        # Save the intermediate history records configured in workflow.py first.
        for intermediate_status in get_intermediate_statuses(ticket, target_status):
            TicketStatus.objects.create(
                ticket_number=ticket,
                status=intermediate_status,
                comments=comments,
                meta_created_by=self.request.user,
            )

        instance = serializer.save(
            ticket_number=ticket,
            status=target_status,
            comments=comments,
            meta_created_by=self.request.user,
        )

        attachments = self.process_files(files)
        handle_announcement_emails(self.request, ticket, target_status, attachments)
        handle_pm_or_salesops_emails(
            self.request, ticket, instance, target_status, comments, attachments
        )

    @staticmethod
    def process_files(files):
        attachment_list = []
        for file_obj in files:
            encoded = base64.b64encode(file_obj.read()).decode("utf-8")
            attachment_list.append({"Name": file_obj.name, "ContentBytes": encoded})
        return attachment_list


class CCIPriceListView(viewsets.ReadOnlyModelViewSet):
    queryset = CCIPriceList.objects.using("elppricelist").all()
    permission_classes = [IsApplicationUser]
    serializer_class = CCIPriceListSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = {"mercury_code_8": ["exact", "in"]}


class ContactEmailsView(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsApplicationUser]
    queryset = ContactEmails.objects.all()
    serializer_class = ContactEmailsSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = {"user_type": ["exact"]}


class AnnouncementMailLinkView(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsApplicationUser]
    queryset = AnnouncementMailLink.objects.all()
    serializer_class = AnnouncementMailLinkSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = {"user_type": ["exact"]}
