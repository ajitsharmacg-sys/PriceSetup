Price Setup Request final files

Files:
- serializers.py: API serializers and metadata fields
- views.py: API endpoints and request handling
- workflow.py: status graph, role validation, intermediate statuses
- email_template.py: HTML email body templates only
- notification.py: recipients, subjects, dispatch, email delivery
- filters.py: latest-status ticket filtering

Copy the Python files into your pricerequest Django app. Review model field names and related_name values against your project before deployment. Run Django checks and workflow/email tests in a development environment before production deployment.
