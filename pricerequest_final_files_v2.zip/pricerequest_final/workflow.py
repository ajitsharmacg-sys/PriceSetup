from collections import defaultdict
from pricerequest.roles import PM_USER, SALES_OPS_USER, ADMIN_ROLE
from pricerequest.models import TicketStatusChoices

TICKET_STATUS_GRAPH = {
    TicketStatusChoices.DRAFT: [TicketStatusChoices.PENDING_SALESOPS_VALIDATION],
    TicketStatusChoices.PENDING_SALESOPS_VALIDATION: [
        TicketStatusChoices.PENDING_SETUP,
        TicketStatusChoices.PENDING_DRBG_ANNOUNCEMENTS,
        TicketStatusChoices.PENDING_ITCG_ANNOUNCEMENTS,
        TicketStatusChoices.SALESOPS_REJECTED,
    ],
    TicketStatusChoices.PENDING_SETUP: [TicketStatusChoices.PENDING_PM_VALIDATION, TicketStatusChoices.PM_REJECTED],
    TicketStatusChoices.PENDING_DRBG_ANNOUNCEMENTS: [TicketStatusChoices.PENDING_ITCG_ANNOUNCEMENTS, TicketStatusChoices.PENDING_PM_VALIDATION],
    TicketStatusChoices.PENDING_ITCG_ANNOUNCEMENTS: [TicketStatusChoices.PENDING_PM_VALIDATION],
    TicketStatusChoices.PENDING_PM_VALIDATION: [TicketStatusChoices.CLOSED, TicketStatusChoices.PM_REJECTED],
    TicketStatusChoices.SALESOPS_REJECTED: [TicketStatusChoices.DRAFT],
    TicketStatusChoices.PM_REJECTED: [TicketStatusChoices.DRAFT],
    TicketStatusChoices.CLOSED: [],
}

TICKET_STATUS_TO_ROLE = {
    TicketStatusChoices.DRAFT: [PM_USER, ADMIN_ROLE],
    TicketStatusChoices.PENDING_SALESOPS_VALIDATION: [SALES_OPS_USER, ADMIN_ROLE],
    TicketStatusChoices.PENDING_SETUP: [SALES_OPS_USER, ADMIN_ROLE],
    TicketStatusChoices.PENDING_DRBG_ANNOUNCEMENTS: [SALES_OPS_USER, ADMIN_ROLE],
    TicketStatusChoices.PENDING_ITCG_ANNOUNCEMENTS: [SALES_OPS_USER, ADMIN_ROLE],
    TicketStatusChoices.PENDING_PM_VALIDATION: [PM_USER, ADMIN_ROLE],
    TicketStatusChoices.CLOSED: [PM_USER, ADMIN_ROLE],
    TicketStatusChoices.PM_REJECTED: [PM_USER, ADMIN_ROLE],
    TicketStatusChoices.SALESOPS_REJECTED: [SALES_OPS_USER, ADMIN_ROLE],
}

# These are history records inserted automatically when a configured destination is reached.
TICKET_INTERMEDIATE_STATUSES = {
    TicketStatusChoices.PENDING_ITCG_ANNOUNCEMENTS: {
        "condition": {"announcement_choice": "ITCG_DRBG"},
        "statuses": [TicketStatusChoices.DRBG_ANNOUNCEMENTS_COMPLETED],
    },
}


def build_role_to_status_mapping(status_to_role):
    role_to_status = defaultdict(list)
    for status, roles in status_to_role.items():
        for role in roles:
            role_to_status[role].append(status)
    return dict(role_to_status)

ROLE_TO_TICKET_STATUS = build_role_to_status_mapping(TICKET_STATUS_TO_ROLE)


def get_available_transitions(current_status, status_graph=TICKET_STATUS_GRAPH):
    return status_graph.get(current_status, [])


def is_valid_transition(current_status, new_status, status_graph=TICKET_STATUS_GRAPH):
    return new_status in get_available_transitions(current_status, status_graph)


def is_valid_ticket_transition(current_status, new_status):
    return is_valid_transition(current_status, new_status, TICKET_STATUS_GRAPH)


def is_role_allowed_for_status(user_roles, target_status, status_to_role=TICKET_STATUS_TO_ROLE):
    return bool(set(user_roles).intersection(status_to_role.get(target_status, [])))


def is_role_allowed_for_ticket_status(user_roles, target_status):
    return is_role_allowed_for_status(user_roles, target_status, TICKET_STATUS_TO_ROLE)


def get_user_roles(user):
    if not user or not user.is_authenticated:
        return []
    return list(user.groups.values_list("name", flat=True))


def get_intermediate_statuses(ticket, target_status):
    config = TICKET_INTERMEDIATE_STATUSES.get(target_status)
    if not config:
        return []
    for field_name, expected_value in config.get("condition", {}).items():
        if getattr(ticket, field_name, None) != expected_value:
            return []
    return config.get("statuses", [])
