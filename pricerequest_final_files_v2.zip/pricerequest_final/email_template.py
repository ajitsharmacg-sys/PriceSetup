default_html_template = """<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
    <h4>Dear All,</h4>"""


default_salesops_signature_template = """<h5>Kind Regards</h5>
<h5>Sales Operations DR</h5>
<h6>We Do</h6>
    <ul style="list-style-type: none; padding-left: 0;">
        <li><small>1.ELP ER DR INFL CIF & E-com price setup</small></li>
        <li><small>2.Local RSP setup & management</small></li>
        <li><small>3.AIF setup & management</small></li>
        <li><small>4.On-Invoice Oracle Modifiers setup</small></li>
    </ul>
</body>
</html>
"""

default_pm_signature_template = """<h5>Kind Regards</h5>
<h5>PM Team DR</h5>
</body>
</html>"""


def prepare_pm_email_body(request, ticket, comments):
    template_text = f"""<h4>A Price Setup Request has been submitted or updated by the PM.</h4>
        <h4>Please take the necessary steps to set up the price list.</h4>
        <br>"""

    if comments is not None and comments != "null":
        template_text += f"Request Comment: {comments}<br>"

    template_text += f"""Request Number: {ticket.ticket_number} <br>
        Link - {request.build_absolute_uri('/pricerequest/')}/<br>
        """

    pm_email_output = (
        f"{default_html_template} {template_text} {default_pm_signature_template}"
    )
    return pm_email_output


def prepare_pm_reject_body(request, ticket, comments):
    template_text = f"""<h4>The Price Setup validation request has been rejected.</h4>
    <h4>We will resubmit the price request with the correct price, which should then be validated and updated in the Oracle master database.</h4>
    </br>"""
    if comments is not None and comments != "null":
        template_text += f"Request Comment: {comments}<br>"

    template_text += f"""Request Number: {ticket.ticket_number} <br>
        Link - {request.build_absolute_uri('/pricerequest/')}/<br>
        """
    pm_reject_output = (
        f"{default_html_template} {template_text} {default_pm_signature_template}"
    )
    return pm_reject_output


def prepare_salesops_reject_body(request, ticket, comments):
    template_text = f"""<h4>The Price Setup Request has been rejected.</h4>
    <h4>Ensure all details are accurate and resubmit the price request accordingly.</h4></br>"""

    if comments is not None and comments != "null":
        template_text += f"Request Comment: {comments}<br>"

    template_text += f"""Request Number: {ticket.ticket_number} <br>
        Link - {request.build_absolute_uri('/pricerequest/')}/<br>
        """
    salesops_reject_output = (
        f"{default_html_template} {template_text} {default_salesops_signature_template}"
    )
    return salesops_reject_output


def prepare_pm_closed_body(request, ticket, comments):
    template_text = f"""<h4>The Price Setup has been validated and the request has been closed by the PM.</h4></br>"""

    if comments is not None and comments != "null":
        template_text += f"Request Comment: {comments}<br>"

    template_text += f"""Request Number: {ticket.ticket_number} <br>
        Link - {request.build_absolute_uri('/pricerequest/')}/<br>
        """

    pm_closed_output = (
        f"{default_html_template} {template_text} {default_pm_signature_template}"
    )
    return pm_closed_output


def prepare_pm_validate_body(request, ticket, comments):
    template_text = f"""<h4>The Price Setup Request has been completed. Please validate the setup and finalize the request.</h4></br>"""
    if comments is not None and comments != "null":
        template_text += f"Request Comment: {comments}<br>"

    template_text += f"""Request Number: {ticket.ticket_number} <br>
        Link - {request.build_absolute_uri('/pricerequest/')}/<br>
        """
    pm_validate_output = (
        f"{default_html_template} {template_text} {default_salesops_signature_template}"
    )
    return pm_validate_output


def prepare_drbg_announcement_body(request, ticket, email_template, links):
    def add_cell(value):
        return f"<td style='padding: 10px; border: 1px solid #ddd;'>{value if value is not None else ''}</td>"

    drbg_email_body = """
        <p>Dear All,</p>
        <p>Please be advised about the new ELPs..</p>
        <br>
        """
    if links:
        for link in links:
            drbg_email_body += (
                f"<p><a href='{link.link_url}' target='_blank'>{link.link_name}</a></p>"
            )

    drbg_email_body += """
        <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd;">
            <thead>
                <tr>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #6495ED; color: white;">Product Group</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #6495ED; color: white;">Model</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #6495ED; color: white;">Mercury Code</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #6495ED; color: white;">Product Name</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #FFB6C1; color: white;">ELP(€)</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #FFB6C1; color: white;">CEE(€)</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #FFB6C1; color: white;">CEA(€)</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #FFB6C1; color: white;">CME(€)</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #FFB6C1; color: white;">CSA(€)</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #FFA500; color: white;">Effective Date</th>
                </tr>
            </thead>
            <tbody>
    """

    for line in ticket.ticket_lines.all():
        has_any_price = any(
            [
                line.cee_price,
                line.cea_price,
                line.cme_price,
                line.csa_price,
            ]
        )
        if has_any_price:
            drbg_email_body += f"""
                <tr>
                    {add_cell(line.product_group)}
                    {add_cell(line.model_budget)}
                    {add_cell(line.mercury)}
                    {add_cell(line.product_name)}
                    {add_cell(line.pelp_price)}
                    {add_cell(line.cee_price)}
                    {add_cell(line.cea_price)}
                    {add_cell(line.cme_price)}
                    {add_cell(line.csa_price)}
                    {add_cell((ticket.cif_start_date.strftime("%d-%b-%Y") if ticket.cif_start_date else ""))}
                </tr>
            """

    drbg_email_body += """
            </tbody>
        </table>
        """

    if email_template != "null":
        drbg_email_body += f"<p><strong></strong> {email_template}</p><br>"

    drbg_email_body += """
        <br><br>
        <p>Kind Regards,<br>
        Sales Operations DR</p>
        <p>
            We Do:<br>
            1. ELP ER DR INFL CIF & E-com price setup<br>
            2. Local RSP setup & management<br>
            3. AIF setup & management<br>
            4. On-Invoice Oracle Modifiers setup
        </p>
    """

    return drbg_email_body


def prepare_itcg_announcement_body(request, ticket, email_template, links):

    def add_cell(value):
        return f"<td style='padding: 10px; border: 1px solid #ddd;'>{value if value is not None else ''}</td>"

    itcg_email_template = "" if email_template == "null" else email_template

    itcg_email_body = """
        <p>Dear All,</p>
        <p>Please be advised about the new ELPs..</p>
        <br>
        """
    itcg_email_body += f"""\
        <p><b><span style="color: red;">
        If you are not happy with Draft RSPs calculated by system; please update your RSP OVERRIDES in the SharePoint link provided below by {itcg_email_template}.
        </span></b></p>
        """

    if links:
        for link in links:
            itcg_email_body += (
                f"<p><a href='{link.link_url}' target='_blank'>{link.link_name}</a></p>"
            )

    itcg_email_body += """
        <small>
            <p><em>*Please note the other 2nd layers for the below items will be priced accordingly.</em></p>

            <p><em>**For Transfer Price list changes; this is only available to country directors, PBD managers and delegates, Product Management, PSBD & Finance.</em><br>
            Please submit a request for access to the CCI Pricing inbox copying your PBD manager or country director.</p>
        </small>
        """

    itcg_email_body += """
        <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd;">
            <thead>
                <tr>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #6495ED; color: white;">Product Group</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #6495ED; color: white;">Model</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #6495ED; color: white;">Mercury Code</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #6495ED; color: white;">Product Name</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #FFB6C1; color: white;">ELP(€)</th>
                    <th style="padding: 10px; border: 1px solid #ddd; background-color: #FFA500; color: white;">Effective Date</th>
                </tr>
            </thead>
            <tbody>
    """

    for line in ticket.ticket_lines.all():
        has_any_price = any(
            [
                line.pelp_price,
            ]
        )
        if has_any_price:
            itcg_email_body += f"""
                <tr>
                    {add_cell(line.product_group)}
                    {add_cell(line.model_budget)}
                    {add_cell(line.mercury)}
                    {add_cell(line.product_name)}
                    {add_cell(line.pelp_price)}
                    {add_cell((ticket.elp_start_date.strftime("%d-%b-%Y") if ticket.elp_start_date else ""))}
                </tr>
            """

    itcg_email_body += """
            </tbody>
        </table>
        <br><br>
        <p>Kind Regards,<br>
        Sales Operations DR</p>
        <p>
            We Do:<br>
            1. ELP ER DR INFL CIF & E-com price setup<br>
            2. Local RSP setup & management<br>
            3. AIF setup & management<br>
            4. On-Invoice Oracle Modifiers setup
        </p>
    """

    return itcg_email_body
