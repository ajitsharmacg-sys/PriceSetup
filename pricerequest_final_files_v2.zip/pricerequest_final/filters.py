from django.db.models import OuterRef, Subquery
from rest_framework import filters
from pricerequest.models import TicketStatus, TicketStatusChoices


class TicketByStatusFilter(filters.BaseFilterBackend):
    """Filter tickets by their latest status history record."""

    def filter_queryset(self, request, queryset, view):
        requested_status = request.query_params.get("ticket_status")
        if not requested_status:
            return queryset
        valid_statuses = {choice[0] for choice in TicketStatusChoices.choices} if hasattr(TicketStatusChoices, "choices") else set(TicketStatusChoices)
        if requested_status not in valid_statuses:
            return queryset.none()
        latest_status = TicketStatus.objects.filter(ticket_number_id=OuterRef("pk")).order_by("-id")
        return queryset.annotate(_latest_ticket_status=Subquery(latest_status.values("status")[:1])).filter(_latest_ticket_status=requested_status)
