from rest_framework import serializers
from common.serializers import CanonUserSimpleSerializer
from pricerequest.models import (
    Ticket, TicketLine, TicketStatus, CCIPriceList, ContactEmails,
    AnnouncementMailLink,
)


class TicketLineReadSerializer(serializers.ModelSerializer):
    meta_created_by = serializers.StringRelatedField(read_only=True, label="Created By")
    meta_edited_by = serializers.StringRelatedField(read_only=True, label="Last Edited By")

    class Meta:
        model = TicketLine
        fields = "__all__"
        read_only_fields = ("meta_created_date", "meta_created_by", "meta_edited_date", "meta_edited_by")


class TicketLineWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketLine
        fields = "__all__"
        read_only_fields = ("meta_created_date", "meta_created_by", "meta_edited_date", "meta_edited_by")


# Backwards-compatible name if any existing code imports TicketLineSerializer.
class TicketLineSerializer(TicketLineReadSerializer):
    pass


class TicketStatusSerializer(serializers.ModelSerializer):
    meta_created_by = serializers.StringRelatedField(read_only=True, label="Created By")

    class Meta:
        model = TicketStatus
        fields = "__all__"
        read_only_fields = ("meta_created_by", "meta_created_date")


class TicketReadSerializer(serializers.ModelSerializer):
    meta_created_by = serializers.SerializerMethodField(label="Created By")
    meta_edited_by = serializers.SerializerMethodField(label="Last Edited By")
    aif_status = serializers.SerializerMethodField(label="Status")

    class Meta:
        model = Ticket
        fields = "__all__"
        read_only_fields = ("meta_created_date", "meta_created_by", "meta_edited_date", "meta_edited_by")

    def get_meta_created_by(self, obj):
        user = getattr(obj, "meta_created_by", None)
        if not user:
            return None
        return user.get_full_name() or str(user)

    def get_meta_edited_by(self, obj):
        user = getattr(obj, "meta_edited_by", None)
        if not user:
            return None
        return user.get_full_name() or str(user)

    def get_aif_status(self, obj):
        latest = obj.status_history.order_by("-id").first() if hasattr(obj, "status_history") else None
        if latest is None:
            # Fall back to the default reverse relation name when no related_name is configured.
            relation = getattr(obj, "ticketstatus_set", None)
            latest = relation.order_by("-id").first() if relation is not None else None
        return latest.status if latest else None


class TicketWriteSerializer(serializers.ModelSerializer):
    meta_created_by = CanonUserSimpleSerializer(read_only=True)
    meta_edited_by = CanonUserSimpleSerializer(read_only=True)

    class Meta:
        model = Ticket
        fields = "__all__"
        read_only_fields = ("meta_created_date", "meta_created_by", "meta_edited_date", "meta_edited_by")


class CCIPriceListSerializer(serializers.ModelSerializer):
    class Meta:
        model = CCIPriceList
        fields = ["price_list_name", "mercury_code", "ln_start_date_active", "ln_end_date_active", "mercury_code_8", "record_date"]


class ContactEmailsSerializer(serializers.ModelSerializer):
    meta_created_by = serializers.StringRelatedField(read_only=True, label="Created By")

    class Meta:
        model = ContactEmails
        fields = "__all__"
        read_only_fields = ("meta_created_by", "meta_created_date")


class AnnouncementMailLinkSerializer(serializers.ModelSerializer):
    meta_created_by = serializers.StringRelatedField(read_only=True, label="Created By")

    class Meta:
        model = AnnouncementMailLink
        fields = "__all__"
        read_only_fields = ("meta_created_by", "meta_created_date")
