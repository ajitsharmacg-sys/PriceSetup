"""Notification dispatch and recipient selection for Price Setup Request."""

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group

from common.email_notifications import send_email, send_email_with_attachments
from pricerequest.models import AnnouncementMailLink, TicketStatusChoices
from pricerequest.roles import PM_USER, SALES_OPS_USER
from pricerequest.email_template import (
    prepare_pm_email_body,
    prepare_pm_reject_body,
    prepare_salesops_reject_body,
    prepare_pm_closed_body,
    prepare_pm_validate_body,
    prepare_drbg_announcement_body,
    prepare_itcg_announcement_body,
)

UserModel = get_user_model()

def prepare_emails_from_group(group_name):
    if not group_name:
        return ""
    group = Group.objects.filter(name=group_name).first()
    if not group:
        return ""
    emails = list(UserModel.objects.filter(groups=group).exclude(email="").values_list("email", flat=True))
    if group_name == SALES_OPS_USER:
        emails.append("cci.pricing@canon-europe.com")
    return ";".join(dict.fromkeys(emails))


def _prepare_email_body_for_drbg_itcg(status, request, ticket, email_template, mail_links):
    if status == TicketStatusChoices.ITCG_ANNOUNCEMENTS_COMPLETED:
        return prepare_itcg_announcement_body(request, ticket, email_template, mail_links)
    if status in (TicketStatusChoices.PENDING_ITCG_ANNOUNCEMENTS, TicketStatusChoices.DRBG_ANNOUNCEMENTS_COMPLETED):
        return prepare_drbg_announcement_body(request, ticket, email_template, mail_links)
    return ""


def _prepare_email_body_from_status(status, request, ticket, comments):
    status_function_map = {
        TicketStatusChoices.PENDING_PM_VALIDATION: prepare_pm_validate_body,
        TicketStatusChoices.PENDING_SALESOPS_VALIDATION: prepare_pm_email_body,
        TicketStatusChoices.PM_REJECTED: prepare_pm_reject_body,
        TicketStatusChoices.SALESOPS_REJECTED: prepare_salesops_reject_body,
        TicketStatusChoices.CLOSED: prepare_pm_closed_body,
    }
    body_function = status_function_map.get(status)
    return body_function(request, ticket, comments) if body_function else ""


def _prepare_email_subject_from_status(status, ticket):
    ticket_number = ticket.ticket_number
    subject_map = {
        TicketStatusChoices.PENDING_PM_VALIDATION: f"{ticket_number} - Price Setup Request to be validated by PM.",
        TicketStatusChoices.PENDING_SALESOPS_VALIDATION: f"{ticket_number} - New Price Setup Request Submitted.",
        TicketStatusChoices.PM_REJECTED: f"{ticket_number} - Price Setup Request rejected by PM.",
        TicketStatusChoices.SALESOPS_REJECTED: f"{ticket_number} - Price Setup Request rejected by SalesOps.",
        TicketStatusChoices.CLOSED: f"{ticket_number} - Price Setup Request closed by PM.",
        TicketStatusChoices.ITCG_ANNOUNCEMENTS_COMPLETED: f"{ticket_number} - DR Announcements.",
    }
    if status in (TicketStatusChoices.PENDING_ITCG_ANNOUNCEMENTS, TicketStatusChoices.DRBG_ANNOUNCEMENTS_COMPLETED):
        return f"{ticket_number} - ER Announcements."
    return subject_map.get(status, f"{ticket_number} - Price Setup for new request")


def send_emails_to_pm_or_salesops(user, status, request, status_record, comments, ticket, attachments=None):
    attachments = attachments or []
    subject = _prepare_email_subject_from_status(status, ticket)
    body = _prepare_email_body_from_status(status, request, ticket, comments)
    cc = ticket.email_cc if ticket.email_cc not in (None, "", "null") else ""
    if user == PM_USER:
        creator = getattr(ticket, "meta_created_by", None)
        to_emails = getattr(creator, "email", "") if creator else ""
    else:
        to_emails = prepare_emails_from_group(user)
    if not to_emails or not body:
        return
    if attachments:
        send_email_with_attachments(to=to_emails, subject=subject, body=body, cc=cc, attachments=attachments)
    else:
        send_email(to=to_emails, subject=subject, body=body, cc=cc)


def send_drbg_or_itcg_announcements(to_emails, status, request, ticket, email_template, cc_emails, mail_links, attachments=None):
    attachments = attachments or []
    subject = _prepare_email_subject_from_status(status, ticket)
    body = _prepare_email_body_for_drbg_itcg(status, request, ticket, email_template, mail_links)
    cc = cc_emails if cc_emails not in (None, "", "null") else ""
    if not to_emails or not body:
        return
    # Preserve previous behavior: announcement messages are sent only with attachments.
    if attachments:
        send_email_with_attachments(to=to_emails, subject=subject, body=body, cc=cc, attachments=attachments)


def handle_announcement_emails(request, ticket, status, attachments):
    post = request.POST
    if status in (TicketStatusChoices.PENDING_ITCG_ANNOUNCEMENTS, TicketStatusChoices.DRBG_ANNOUNCEMENTS_COMPLETED):
        links = AnnouncementMailLink.objects.filter(user_type="DRBG")
        send_drbg_or_itcg_announcements(post.get("drbg_to_emails"), status, request, ticket, post.get("drbg_email_template"), post.get("drbg_cc_emails"), links, attachments)
    if status == TicketStatusChoices.ITCG_ANNOUNCEMENTS_COMPLETED:
        links = AnnouncementMailLink.objects.filter(user_type="ITCG")
        send_drbg_or_itcg_announcements(post.get("itcg_to_emails"), status, request, ticket, post.get("itcg_email_template"), post.get("itcg_cc_emails"), links, attachments)


def handle_pm_or_salesops_emails(request, ticket, status_record, status, comments, attachments):
    if status in (TicketStatusChoices.PENDING_PM_VALIDATION, TicketStatusChoices.SALESOPS_REJECTED):
        send_emails_to_pm_or_salesops(PM_USER, status, request, status_record, comments, ticket, attachments)
    if status in (TicketStatusChoices.PENDING_SALESOPS_VALIDATION, TicketStatusChoices.PM_REJECTED, TicketStatusChoices.CLOSED):
        send_emails_to_pm_or_salesops(SALES_OPS_USER, status, request, status_record, comments, ticket, attachments)
